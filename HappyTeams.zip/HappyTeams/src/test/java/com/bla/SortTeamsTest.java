/******************************************
 * Author: ndf17a Nicolas Fornicola
 * Class: Spring 2020 Dr,Reeves CS 374 SE
 * Task: Accepting a file string test
 * Due Date: 1/24/2020
 *
 * Test all the functions inside of Calculator.java will throw exceptions if test fail
 */
package com.bla;

import java.util.Arrays;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.*;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.junit.*;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class SortTeamsTest
{
	SortTeams happy;
	
	@Before //Before anything
    public void initialize()
	{
		happy = new SortTeams();
		happy.assignTeamSize(3);
		happy.main("choice/test1.txt");
		
    }
	
	//The testCheckNames cannot change test files, if they change test files it will fail
	//If TeamSize is change it could also fail, this passes because atleast one placeholder is needed
	@Test
	public void testCheckedNames1()
	{
		try
		{
			System.out.println("RUNNING testCheckedNames1");
			String checkedNames[] = happy.get("choice/test2.txt");
			
			assertEquals("Bubba,2,3,6,5,4", checkedNames[0]);
			assertEquals("Adam,2,3,6,5,4", checkedNames[checkedNames.length/2]);
			assertEquals("Placeholder", checkedNames[checkedNames.length-1]);
		}
		catch (Exception e)
		{
			System.out.println("TESTCHECKEDNAMES1 NOT WORKING");
		}
	}
	
	/*/*The testCheckNames cannot change test files, if they change test files it will fail
	//If TeamSize is change it could also fail, this passes because atleast one placeholder is needed
	@Test
	public void testCheckedNames2()
	{
		try
		{
			System.out.println("RUNNING testCheckedNames2");
			String checkedNames[] = happy.get("choice/test3.txt");
			
			assertEquals("Bubba,2,3", checkedNames[0]);
			assertEquals("Adam,2,3,6,5,4", checkedNames[checkedNames.length/2]);
			assertEquals("Placeholder", checkedNames[checkedNames.length-1]);
		}
		catch (Exception e)
		{
			System.out.println("TESTCHECKEDNAMES2 NOT WORKING");
		}
	}
	
	//Shuffles the tempPrio array and tempNames array then checks to see if they are different from their originals
	@Test
	public void testShuffle1()
	{
		try
		{
			
			System.out.println("RUNNING testShuffle1");
			String checkedNames[] = happy.get("choice/test1.txt");
			String prio[] = happy.getPrio(checkedNames);
			happy.shuffle();
			String tempPrio[] = happy.viewTempPrio();
			String tempNames[] = happy.viewTempNames();
			//This wants to be NOT equal, so the Arrays.equals need to return false.
			assertNotEquals(Arrays.equals(prio, tempPrio), true);
			assertNotEquals(Arrays.equals(checkedNames, tempNames), true);
			
		}
		catch (Exception e)
		{
			System.out.println("TESTSHUFFLE1 NOT WORKING");
		}
	}
	
	@Test
	public void testShuffle2()
	{
		try
		{
			System.out.println("RUNNING testShuffle2");
			String checkedNames[] = happy.get("choice/test2.txt");
			String prio[] = happy.getPrio(checkedNames);
			happy.shuffle();
			String tempPrio[] = happy.viewTempPrio();
			String tempNames[] = happy.viewTempNames();
			//This wants to be NOT equal, so the Arrays.equals need to return false.
			assertNotEquals(Arrays.equals(prio, tempPrio), true);
			assertNotEquals(Arrays.equals(checkedNames, tempNames), true);
			
		}
		catch (Exception e)
		{
			System.out.println("TESTSHUFFLE2 NOT WORKING");
		}
	}
	
	@Test
	public void testShuffle3()
	{
		try
		{
			System.out.println("RUNNING testShuffle3");
			String checkedNames[] = happy.get("choice/test3.txt");
			String prio[] = happy.getPrio(checkedNames);
			happy.shuffle();
			String tempPrio[] = happy.viewTempPrio();
			String tempNames[] = happy.viewTempNames();
			//This wants to be NOT equal, so the Arrays.equals need to return false.
			assertNotEquals(Arrays.equals(prio, tempPrio), true);
			assertNotEquals(Arrays.equals(checkedNames, tempNames), true);
			
		}
		catch (Exception e)
		{
			System.out.println("TESTSHUFFLE3 NOT WORKING");
		}
	}
	
	//Dont change the test file, if it is changed the test may fail 
	@Test
	public void viewPlaceholder1()
	{
		try
		{
			System.out.println("RUNNING viewPlaceholder1");
			happy.assignTeamSize(2);
			happy.get("choice/test1.txt");

			int calcInt = happy.viewPlaceholder();
			int expectedInt = 1;
			assertEquals(expectedInt, calcInt);
		}
		catch (Exception e)
		{
			System.out.println("VIEWPLACEHOLDER1 NOT WORKING");
		}
	}
	
	//Dont change the test file, if it is changed the test may fail 
	@Test
	public void viewPlaceholder2()
	{
		try
		{
			System.out.println("RUNNING viewPlaceholder2");
			happy.assignTeamSize(3);
			happy.get("choice/test2.txt");

			int calcInt = happy.viewPlaceholder();
			int expectedInt = 1;
			assertEquals(expectedInt, calcInt);
		}
		catch (Exception e)
		{
			System.out.println("VIEWPLACEHOLDER2 NOT WORKING");
		}
	}
	
	//Dont change the test file, if it is changed the test may fail 
	@Test
	public void viewPlaceholder3()
	{
		try
		{
			System.out.println("RUNNING viewPlaceholder3");
			happy.assignTeamSize(4);
			happy.main("choice/test3.txt");

			int calcInt = happy.viewPlaceholder();
			int expectedInt = 0;
			assertEquals(expectedInt, calcInt);
		}
		catch (Exception e)
		{
			System.out.println("VIEWPLACEHOLDER2 NOT WORKING");
		}
	}
	
	//Dont change the test file, if it is changed the test may fail 
	@Test
	public void viewPlaceholder4()
	{
		try
		{
			System.out.println("RUNNING viewPlaceholder4");
			happy.assignTeamSize(5);
			happy.main("choice/test3.txt");

			int calcInt = happy.viewPlaceholder();
			int expectedInt = 2;
			assertEquals(expectedInt, calcInt);
		}
		catch (Exception e)
		{
			System.out.println("VIEWPLACEHOLDER4 NOT WORKING");
		}
	}
	
	@Test
	public void viewTeamSizeTest1()
	{
		try
		{
			//Checks default teamSize from the initialization
			System.out.println("RUNNING viewTeamSizeTest1");
			int calcInt = happy.viewTeamSize();
			int expectedInt = 3;
			assertEquals(expectedInt, calcInt);
		}
		catch (Exception e)
		{
			System.out.println("TEAMSIZE1 NOT WORKING");
		}
	}
	
	@Test
	public void viewTeamSizeTest2()
	{
		try
		{
			//Change the teamSize and check again
			System.out.println("RUNNING viewTeamSizeTest2");
			happy.assignTeamSize(5);
			int calcInt = happy.viewTeamSize();
			int expectedInt = 5;
			assertEquals(expectedInt, calcInt);
		}
		catch (Exception e)
		{
			System.out.println("TEAMSIZE2 NOT WORKING");
		}
	}*/
	
	/*@Test
	public void testCalculate()
	{
		try
		{
			//Change the teamSize and check again
			System.out.println("RUNNING testCalculate");
			String checkedNames[] = happy.get("choice/test3.txt");
			String prio[] = happy.getPrio(checkedNames);
			
			happy.calculate(checkedNames, prio);
			//assertEquals(expectedInt, calcInt);
		}
		catch (Exception e)
		{
			System.out.println("TESTCALCULATE2 NOT WORKING");
		}
	}*/
}

