/******************************************
 * Author: ndf17a Nicolas Fornicola
 * Class: Spring 2020 Dr,Reeves CS 374 SE
 * Task: Accept a list of names from a page
 * Due Date: 2/11/2020
 *
 */
package com.bla;

import java.util.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.io.IOException;
import java.util.Arrays;
import java.util.Random; 

public class SortTeams 
{
	// global varriables
	private static int teamSize = 3; // changable
	private static String content;
	private static String[] names;
	private static String[] checkedNames;
	private static String[] prio;
	private static String[] tempNames;
	private static String[] tempPrio;
	private static int placeholder = 0;
	private static int tempPlaceholder = 0;
	private static int Hapiness = 0;
	private static int average = 0;
	private static int testHapiness = 0;
	private static int testAverage = 0;

	//setters
	public static void assignTeamSize(int inputSize) { teamSize = inputSize; }
	public static void assignPlaceholder(int inputPlaceholder) { placeholder = inputPlaceholder; }
	
	//getters
	public static int viewTeamSize() { return teamSize; }
	public static int viewPlaceholder() { return placeholder; }
	public static String[] viewNames() { return names; }
	public static String[] viewCheckedNames() { return checkedNames; }
	public static String[] viewPrio() { return prio; }
	public static String[] viewTempNames() { return tempNames; }
	public static String[] viewTempPrio() { return tempPrio; }
	
	public static void main(String path) 
	{
		//get the first two arrays sorted from the file
		checkedNames = get(path);
		prio = getPrio(checkedNames);
		
		//for(int i = 0; i < 1000; i++)
		//{
		//Find the hapiness of the groups
		shuffle();
		calculate(tempNames, tempPrio);
		//Find if testHapiness or Hapiness is better 
		//compare();
		//shuffle these suckers
		//}
		
	}

	//Gets the names and sorts into teamSize number add placeholders if needed
	public static String[] get(String path) 
	{		
        try
		{
			assignPlaceholder(0);
			tempPlaceholder = 0;

            content = Files.readString(Paths.get(path));
			//this outputs the string with "mvn test" under the T E S T S
			/*System.out.println("=====================================");
			System.out.println("This is the unaltered text from the file\n");
            System.out.println(content);*/
			
			//Splits the content into an array "names" where it finds a \n which is endline
			names = content.split("\n");
			
			//Finds the length of the array, this number starts at 1
			int length = names.length;
			//Find if there is a remainder
			int remainder = length % teamSize;
			//int placeholder = 0;
			if( teamSize-remainder!=teamSize )
				assignPlaceholder(teamSize-remainder);
					
			if(length == 1)
			{
				System.out.println("Nice try, minimum team size of 2...");
				return names;
			}
			
			//adding a certain number of spots to length to make a new array with
			//Either 0 or a number needed
			length += placeholder;
			
			//Make the new array with the new length 
			String[] checkedNames = new String[length];
			
			//Length is -1 is this for loop because we need to account for starting at 0
			//Go through and make the array equal up to the length of the old array
			for(int i = 0; i <= names.length-1; i++)
			{
				checkedNames[i] = names[i];
			}
			
			//if we need to assign Placeholder spots to the new array and label them
			if(remainder > 0)
			{
				tempPlaceholder = viewPlaceholder(); // so that we don't change placeholder
				int i = length-tempPlaceholder;
				while(tempPlaceholder != 0)
				{
					checkedNames[i] = "Placeholder";
					i++;
					tempPlaceholder--;
				}
			}
			return checkedNames;
        } 
		catch (IOException e) {
            e.printStackTrace();
			//if nothing is found return an exception wrong
			return names;
        }	
	}

	//This function splices more things and puts each priority and name in a seperate index it fills spots with no preference with NP and handles placeholders
	public static String[] getPrio(String[] names)
	{
		prio = new String[names.length * 7];
		int start = 0;
		
		for(int i = 0; i < names.length; i++)
		{
			String[] spliced = names[i].split(",");

			System.arraycopy(spliced, 0, prio, start, spliced.length);
			start += 7;		
		}
		
		for(int i = 0; i < prio.length; i++)
			if(prio[i] == null)
				prio[i] = "---";
		
		return prio;
	}
	
	//Shuffle the decks
	public static void shuffle()
	{
		
		tempNames = new String[checkedNames.length];
		tempPrio = new String[prio.length];
		
		for(int i = 0; i < prio.length; i++)
			tempPrio[i] = prio[i];
		
		for(int i = 0; i < tempNames.length; i++)
			tempNames[i] = checkedNames[i];
		
		Random rand = new Random(); 
		// Generate random integers in range 0 to length of either array 
		int switchA = rand.nextInt(checkedNames.length-1); 
		int switchB = rand.nextInt(checkedNames.length-1);
		
		while(switchA == switchB)
			switchB = rand.nextInt(checkedNames.length-1); 
		
		int switchP = switchA * 7;
		int switchQ = switchB * 7;
		
		String nameSwap;
		String prioSwap;
		
		//switch the two
		//maybe check if the thing is a placeholder if it is find somthing else to swap
		nameSwap = tempNames[switchA];
		tempNames[switchA] = tempNames[switchB];
		tempNames[switchB] = nameSwap;
		
		//swap the 7 index in deckPrio
		//check to see if this works
		for(int i = 0; i < 7; i++)
		{
			prioSwap = tempPrio[switchP+i];
			tempPrio[switchP+i] = tempPrio[switchQ+i];
			tempPrio[switchQ+i] = prioSwap;
		}
	}
	
	public static void compare()
	{
		//what should we do if the hapiness is the same? go with the change or do nothing?
		if(Hapiness < testHapiness)
		{
			prio = tempPrio;
			checkedNames = tempNames;
		}
	}
	
	public static void calculate(String[] listNames, String[] listPrio)
	{
		
		String[] tPrio = new String[listPrio.length];//63
		String[] tchecked = new String[listNames.length/teamSize];//3
		
		//used for assining tchecked to the first group, it takes the first 3 name from a list of 9 names for example 
		//then it will take 4,5,6 of 9
		//for(int n = 0; n < listNames.length/teamSize; n++)
		//{
			//System.arraycopy(listNames, teamSize*n, tchecked, 0, teamSize);
			
		
		

		for(int p = 0; p < listPrio.length; p++)
			System.out.println(listPrio[p]);
			System.out.println("!!!");
			System.out.println("");
		
		
		for(int j = 0; j < tchecked.length; j++)
		{
			System.arraycopy(listPrio, 7*j, tPrio, 0, 7);
			
			for(int p = 0; p < tPrio.length; p++)
				System.out.println(listPrio[p]);
				System.out.println("!!!");
			
			for(int i = 0; i < teamSize; i++)
			{
				for(int k = 0; k < 7; k++)
				{
					if(listNames[i] == tPrio[k])
					{
						//add things
					}
					
			
				}
			}
		}	
		
		//}		
		//FROM test starting at index 4 into temp starting at index 0, passing 1,2,3,4,5 things
		//System.arraycopy(test, 5, temp1, 0, 5);*/
		
	}
}
	